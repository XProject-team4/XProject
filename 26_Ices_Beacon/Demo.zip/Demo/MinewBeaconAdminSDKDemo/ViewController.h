//
//  ViewController.h
//  MinewBeaconAdminSDKDemo
//
//  Created by SACRELEE on 27/09/2016.
//  Copyright © 2016 minewTech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

